# Modulul webtools.py
import requests

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def fetch(url, timeout=TIMEOUT):
    """Returnează obiectul răspuns pentru un URL dat."""
    return requests.get(url, timeout=timeout)

def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

def get_title(html):
    """Extrage titlul dintr-un șir HTML folosind metode de căutare și feliere."""
    tag_start = "<title>"
    tag_end = "</title>"
    start = html.find(tag_start)
    if start == -1:
        return None
    start += len(tag_start)
    end = html.find(tag_end, start)
    if end == -1:
        return None
    return html[start:end].strip()

def security_headers(url):
    """Verifică prezența antetelor de securitate și returnează un dicționar {antet: True/False}."""
    response = requests.get(url, timeout=TIMEOUT)
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    return {h: h in response.headers for h in headers_to_check}

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))

DEFAULT_HEADERS = {"User-Agent": "WebLab-Dorofei-Topala"}

def fetch(url, timeout=TIMEOUT):
    """Returnează obiectul răspuns pentru un URL dat, folosind antetele implicite."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)

def _format_url(url):
    """Asigură că URL-ul începe cu o schemă validă (http:// sau https://)."""
    if not url.startswith(("http://", "https://")):
        return "https://" + url
    return url

def fetch(url, timeout=TIMEOUT):
    """Returnează obiectul răspuns pentru un URL dat, formatat și folosind antetele implicite."""
    formatted_url = _format_url(url)
    return requests.get(formatted_url, headers=DEFAULT_HEADERS, timeout=timeout)