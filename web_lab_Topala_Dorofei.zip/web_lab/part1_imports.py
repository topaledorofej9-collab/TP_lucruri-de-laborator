BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 1. Primul import
import requests
import urllib.request

print("Versiunea requests:", requests.__version__)

# Explicație:
# Requests a avut nevoie de "pip install" deoarece este o bibliotecă externă 
# (nu face parte din pachetul standard instalat odată cu Python).
# Urllib.request nu a avut nevoie de instalare suplimentară deoarece este un modul integrat în biblioteca standard Python.

# Exercițiul 2. Două stiluri de import
import requests

# Stilul 1: Importul întregului modul
response1 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stil 1 - Cod de stare:", response1.status_code)

# Stilul 2: Importul unei singure funcții (from requests import get)
from requests import get

response2 = get(BASE_URL, timeout=TIMEOUT)
print("Stil 2 - Cod de stare:", response2.status_code)

# Avantaje:
# - Avantajul importului întregului modul (import requests): Evită conflictele de nume 
#   și este clar din ce bibliotecă provine funcția (vezi requests.get).
# - Avantajul importului specific (from requests import get): Codul devine mai scurt 
#   și mai facil de scris, nemaifiind nevoie să repeți numele modulului (folosești direct get).

# Exercițiul 3. Alias-uri
import requests as rq

response3 = rq.get(BASE_URL, timeout=TIMEOUT)
print("Stil 3 (cu alias rq) - Cod de stare:", response3.status_code)

# Comentariu:
# - Alias-ul face codul mai ușor de citit atunci când numele bibliotecii este lung 
#   sau când folosești frecvent o bibliotecă cu un scurtin, economisind spațiu 
# - Alias-ul face codul mai greu de citit dacă folosești abrevieri personalizate 
#   neobișnuite, deoarece altor programatori (sau ție mai târziu) le va fi 
#   greu să recunoască ce bibliotecă ascunde prescurtarea respectivă.

# Exercițiul 4. Doar biblioteca standard
import urllib.request

# Creăm un obiect Request și adăugăm un antet User-Agent pentru a nu primi eroarea 403 Forbidden
req = urllib.request.Request(
    BASE_URL,
    headers={"User-Agent": "Mozilla/5.0"}
)

with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
    status = response.status
    body_text = response.read().decode("utf-8")
    
    print("Ex 4 - Status (urllib):", status)
    print("Ex 4 - Primele 200 caractere:")
    print(body_text[:200])

   
# Exercițiul 5. Priviți în interiorul unui modul
import requests

# Afișăm tot ce conține modulul requests
# print(dir(requests))

print("Ex 5 - S-a rulat cu succes. Verifică comentariile pentru cele 3 elemente.")

# Exercițiul 6. Citiți documentația
import requests

response6 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex 6 - Cerere cu timeout reușită, status:", response6.status_code)

# Exercițiul 7. Cronometrarea unei cereri
import time
import requests

# Măsurăm timpul de execuție folosind time.perf_counter() înainte și după cerere
start_time = time.perf_counter()
response7 = requests.get(BASE_URL, timeout=TIMEOUT)
end_time = time.perf_counter()

manual_duration = end_time - start_time

print(f"Ex 7 - Timp măsurat manual (perf_counter): {manual_duration:.4f} secunde")
print(f"Ex 7 - Timp măsurat intern (response.elapsed): {response7.elapsed.total_seconds()} secunde")

# Exercițiul 8. Când un import eșuează
try:
    import bs4
    print("Ex 8 - Modulul bs4 este deja instalat.")
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")