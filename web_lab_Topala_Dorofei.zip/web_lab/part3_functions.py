import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  

# Exercițiul 21. Prima funcție
def fetch(url):
    """Trimite o cerere GET către url și returnează obiectul răspuns."""
    response = requests.get(url, timeout=TIMEOUT)
    return response
res = fetch(BASE_URL)
print(f"Ex 21 - Cod de stare pentru BASE_URL: {res.status_code}")

# Exercițiul 22. Returnarea unei singure valori
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

paths = ["/", "/robots.txt", "/sitemap.xml"]
for path in paths:
    full_url = BASE_URL + path
    status = get_status(full_url)
    print(f"Ex 22 - Calea {path} -> Cod de stare: {status}")
    time.sleep(1)

# Exercițiul 23. Parametri impliciți
def fetch_with_timeout(url, timeout=10):
    """Trimite o cerere GET folosind un timeout specificat (implicit 10 secunde)."""
    response = requests.get(url, timeout=timeout)
    return response

res_default = fetch_with_timeout(BASE_URL)
print(f"Ex 23 - Apel cu timeout implicit: status {res_default.status_code}")
time.sleep(1)
res_custom = fetch_with_timeout(BASE_URL, timeout=3)
print(f"Ex 23 - Apel cu timeout=3: status {res_custom.status_code}")

# Exercițiul 24. O singură sarcină pe funcție
def get_title(html):
    """Extrage titlul dintr-un șir HTML folosind metode de căutare și feliere."""
    tag_start = "<title>"
    tag_end = "</title>"
    
    start = html.find(tag_start)
    if start == -1:
        return None
    start += len(tag_start)
    
    end = html.find(tag_end, start)
    if end == -1:
        return None
        
    return html[start:end].strip()

response = requests.get(BASE_URL, timeout=TIMEOUT)
title = get_title(response.text)
print(f"Ex 24 - Titlul extras: {title}")

# Exercițiul 25. Docstring-uri
help(get_title)

# Exercițiul 26. Adnotări de tip
def get_status_typed(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url, cu adnotări de tip."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code
try:
    print(get_status_typed(123))
except Exception as e:
    print(f"Ex 26 - Eroare apărută la apelul cu argument invalid: {e}")

# Exercițiul 27. Fără opriri neașteptate
def page_exists(url: str) -> bool:
    """Verifică dacă o pagină web există și poate fi accesată; returnează True sau False."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        response.raise_for_status()
        return True
    except requests.RequestException:
        return False
print("Ex 27 - Pagina validă există?:", page_exists(BASE_URL))
print("Ex 27 - Pagina invalidă există?:", page_exists("https://this-domain-does-not-exist.invalid"))

# Exercițiul 28
def check_paths(base, paths):
    """Primește o bază și o listă de căi; returnează un dicționar {path: status_code}."""
    results = {}
    for path in paths:
        url = base + path
        try:
            response = requests.get(url, timeout=TIMEOUT)
            results[path] = response.status_code
        except requests.RequestException:
            results[path] = None
        time.sleep(1)
    return results
paths_to_check = ["/", "/robots.txt", "/sitemap.xml"]
path_statuses = check_paths(BASE_URL, paths_to_check)
print(f"Ex 28 - Rezultate căi: {path_statuses}")

# Exercițiul 29
def get_header(url, name, default="lipsește"):
    """Trimite o cerere către url și returnează valoarea unui antet specificat, sau default dacă lipsește."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)
server_header_val = get_header(BASE_URL, name="Server")
print(f"Ex 29 - Valoarea antetului Server: {server_header_val}")

# Exercițiul 30
def security_headers(url):
    response = requests.get(url, timeout=TIMEOUT)
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    return {h: h in response.headers for h in headers_to_check}
sec_headers = security_headers(BASE_URL)
print(f"Ex 30 - Antete de securitate: {sec_headers}")

# Exercițiul 31
def score_headers(results):
    passed = sum(1 for val in results.values() if val)
    total = len(results)
    return f"{passed}/{total}"

score = score_headers(security_headers(BASE_URL))
print(f"Ex 31 - Scor antete de securitate: {score}")

# Exercițiul 32
def fetch_robots(base):
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    if robots_text is None:
        return []
    disallowed = []
    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            if path:
                disallowed.append(path)
    return disallowed

robots_content = fetch_robots(BASE_URL)
disallowed = disallowed_paths(robots_content)
print(f"Ex 32 - Căi interzise din robots.txt: {disallowed}")

# Exercițiul 33
def response_times(*urls):
    times = {}
    for url in urls:
        start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
        except requests.RequestException:
            pass
        end = time.perf_counter()
        times[url] = end - start
    return times

res_times = response_times(BASE_URL, "https://httpbin.org")
print(f"Ex 33 - Timpi de răspuns: {res_times}")

# Exercițiul 34
def log(message, **details):
    """Afișează un mesaj însoțit de detalii suplimentare colectate ca argumente cu nume."""
    parts = [message]
    for key, value in details.items():
        parts.append(f"{key}={value}")
    print(" | ".join(parts))

# Testarea funcției
log("verificat", url=BASE_URL, status=200)