BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 9. Elementele de bază ale răspunsului
import requests

response = requests.get(BASE_URL, timeout=TIMEOUT)

print("Status code:", response.status_code)  
print("OK:", response.ok)                    
print("URL:", response.url)                  
print("Encoding:", response.encoding)        

# Exercițiul 10. Tratarea erorilor cu o metodă
import requests

try:
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    response.raise_for_status()
    print("Ex 10 - Pagina principală a trecut de verificare.")

    bad_url = BASE_URL + "/this-page-does-not-exist"
    response_bad = requests.get(bad_url, timeout=TIMEOUT)
    response_bad.raise_for_status()

except requests.HTTPError as err:
    print(f"Ex 10 - Prins o eroare HTTP prietenos: {err} (Pagina nu a fost găsită sau a apărut o problemă).")

    # Exercițiul 11. Toate antetele
import requests

response11 = requests.get(BASE_URL, timeout=TIMEOUT)

print("Ex 11 - Antetele răspunsului:")
for key, value in response11.headers.items():
    print(f"{key}: {value}")

 # Exercițiul 12. Metode de dicționar
import requests

response12 = requests.get(BASE_URL, timeout=TIMEOUT)

# Folosim .get() cu valoare implicită "lipsește"
server_header = response12.headers.get("Server", "lipsește")
content_type = response12.headers.get("Content-Type", "lipsește")
content_type_lower = response12.headers.get("content-type", "lipsește")

print("Ex 12 - Server:", server_header)
print("Ex 12 - Content-Type (normal):", content_type)
print("Ex 12 - content-type (cu litere mici):", content_type_lower)

# Exercițiul 13. Înlănțuirea metodelor de șir
import requests

response13 = requests.get(BASE_URL, timeout=TIMEOUT)

cyber_count = response13.text.lower().count("cyber")
print(f"Ex 13 - Numărul de apariții ale cuvântului 'cyber': {cyber_count}")

# Explicatie:
# Putem înlănțui .lower() și .count() deoarece .lower() returnează un obiect de tip șir de caractere (string), 
# iar tipul string din Python are la rândul său definită metoda .count(). 
# Astfel, rezultatul primei metode devine imediat obiectul pe care se apelează a doua metodă.

# Exercițiul 14. Găsirea titlului
import requests

response14 = requests.get(BASE_URL, timeout=TIMEOUT)
html = response14.text

tag_start = "<title>"
tag_end = "</title>"

start = html.find(tag_start) + len(tag_start)
end = html.find(tag_end)

title = html[start:end].strip()

print(f"Ex 14 - Titlul paginii: {title}")

# Exercițiul 15. Numărarea liniilor
import requests

response15 = requests.get(BASE_URL, timeout=TIMEOUT)

lines = response15.text.splitlines()
line_count = len(lines)

longest_line = max(lines, key=len)
max_length = len(longest_line)

print(f"Numărul total de linii: {line_count}")
print(f"Lungimea celei mai lungi linii: {max_length} caractere")

# Exercițiul 16. Verificarea HTTPS
import requests

response16 = requests.get(BASE_URL, timeout=TIMEOUT)

if response16.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

    # Exercițiul 17. Urmărirea redirecționărilor
import requests

# Trimitem cerere către HTTP simplu (fără S) pentru a declanșa redirecționarea
response17 = requests.get("http://cybercor.org", timeout=TIMEOUT)

print("Ex 17 - Istoricul redirecționărilor:")
for resp in response17.history:
    print(f"  Cod stare: {resp.status_code} -> URL: {resp.url}")

print(f"URL-ul final: {response17.url}")

# Exercițiul 18. HEAD versus GET
import requests

response_head = requests.head(BASE_URL, timeout=TIMEOUT)
response_get = requests.get(BASE_URL, timeout=TIMEOUT)

print(f"Ex 18 - Lungime conținut HEAD: {len(response_head.content)}")
print(f"Ex 18 - Lungime conținut GET: {len(response_get.content)}")

# Explicație:
# Cererea HEAD returnează doar antetele HTTP, fără corpul paginii (body), 
# motiv pentru care len(response_head.content) este 0. 
# În schimb, cererea GET returnează atât antetele, cât și corpul complet al paginii HTML, 
# deci len(response_get.content) va fi egal cu dimensiunea în octeți a întregii pagini.

# Exercițiul 19. Cookie-uri
import requests

response19 = requests.get(BASE_URL, timeout=TIMEOUT)

if response19.cookies:
    print("Ex 19 - Cookie-uri găsite:")
    for cookie in response19.cookies:
        print(f"  Nume: {cookie.name}, Secure: {cookie.secure}")
else:
    print("Ex 19 - Niciun cookie setat.")

# Exercițiul 20. Sesiuni
import requests
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Topala-Dorofei"})
response20 = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Ex 20 - Răspuns de la httpbin (antete trimise):")
print(response20.text)