import requests
import time
import urllib.parse

BASE_URL = "https://cybercor.org"
TIMEOUT = 10  # secunde

# Exercițiul 35
url = "https://cybercor.org/path?x=1#top"
parsed_url = urllib.parse.urlparse(url)

print(f"Ex 35 - Scheme: {parsed_url.scheme}")
print(f"Ex 35 - Netloc: {parsed_url.netloc}")
print(f"Ex 35 - Path: {parsed_url.path}")
print(f"Ex 35 - Query: {parsed_url.query}")
print(f"Ex 35 - Fragment: {parsed_url.fragment}")

# Exercițiul 36
relative_links = ["/about", "contact.html", "../index.html"]
for link in relative_links:
    full_url = urllib.parse.urljoin(BASE_URL, link)
    print(f"Ex 36 - {link} -> {full_url}")

# Exercițiul 37
import re

def extract_links(html):
    """Extrage toate legăturile dintr-un șir HTML și returnează o listă unică (fără duplicate)."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(set(links))
response = requests.get(BASE_URL, timeout=TIMEOUT)
unique_links = extract_links(response.text)
print(f"Ex 37 - Legături unice găsite: {unique_links}")

# Exercițiul 38
def split_links(links, domain):
    """Împarte o listă de legături în două categorii: interne (același domeniu) și externe."""
    internal = []
    external = []
    
    parsed_domain = urllib.parse.urlparse(domain).netloc
    
    for link in links:
        absolute_url = urllib.parse.urljoin(domain, link)
        parsed_link = urllib.parse.urlparse(absolute_url)
        
        if parsed_link.netloc == parsed_domain or not parsed_link.netloc:
            internal.append(absolute_url)
        else:
            external.append(absolute_url)
            
    return internal, external
internal_links, external_links = split_links(unique_links, BASE_URL)
print(f"Ex 38 - Legături interne: {len(internal_links)}")
print(f"Ex 38 - Legături externe: {len(external_links)}")

# Exercițiul 39
from html.parser import HTMLParser

class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)

test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print("Ex 39 - Test imagini:", finder.images)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")
response = requests.get(BASE_URL, timeout=TIMEOUT)
finder_real = ImageFinder()
finder_real.feed(response.text)
print(f"Ex 39 - Imagini găsite pe site: {len(finder_real.images)}")

# Exercițiul 40
import hashlib

def page_fingerprint(url):
    """Calculează amprenta criptografică SHA-256 a conținutului paginii web."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()
fp1 = page_fingerprint(BASE_URL)
print(f"Ex 40 - Prima rulare a amprentei: {fp1}")

fp2 = page_fingerprint(BASE_URL)
print(f"Ex 40 - A doua rulare a amprentei: {fp2}")

print(f"Amprentele sunt identice?: {fp1 == fp2}")

# Exercițiul 41
import json

response = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(response.headers), f, indent=2)
with open("headers.json", "r", encoding="utf-8") as f:
    loaded_headers = json.load(f)
server_val = loaded_headers.get("Server", "lipsește")
print(f"Ex 41 - Antetul Server încărcat din JSON: {server_val}")

# Exercițiul 42. Interogare DNS
import socket

def resolve(hostname):
    """Returnează adresa IP pentru un hostname dat folosind modulul socket."""
    return socket.gethostbyname(hostname)
ip_address = resolve("cybercor.org")
print(f"Ex 42 - Adresa IP pentru cybercor.org: {ip_address}")

# Exercițiul 43. Expirarea certificatului
import ssl
from datetime import datetime, timezone

def cert_days_left(hostname):
    """Calculează câte zile mai sunt până la expirarea certificatului SSL al unui hostname."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after_str = cert["notAfter"]
            expiry_seconds = ssl.cert_time_to_seconds(not_after_str)
            expiry_date = datetime.fromtimestamp(expiry_seconds, tz=timezone.utc)
            current_date = datetime.now(timezone.utc)
            delta = expiry_date - current_date
            return delta.days
days_left = cert_days_left("cybercor.org")
print(f"Ex 43 - Zile rămase până la expirarea certificatului: {days_left} zile")