# Programul principal main.py - Exercițiul 50 (Tabloul de bord web)
import webtools

def audit_dashboard(url):
    print("=" * 50)
    print(f" RAPORT DE AUDIT PENTRU: {url}")
    print("=" * 50)
    
    try:
        response = webtools.fetch(url)
        print(f"[+] Status HTTP: {response.status_code}")
        
        title = webtools.get_title(response.text)
        print(f"[+] Titlul paginii: {title if title else 'N/A'}")
        
        sec_headers = webtools.security_headers(url)
        print("[+] Antete de securitate detectate:")
        passed = 0
        for header, present in sec_headers.items():
            status_icon = "✓" if present else "✗"
            print(f"    [{status_icon}] {header}: {present}")
            if present:
                passed += 1
                
        score = f"{passed}/{len(sec_headers)}"
        print(f"[+] Scor securitate antete: {score}")
        
    except Exception as e:
        print(f"[-] Eroare la efectuarea auditului: {e}")
        
    print("=" * 50)

if __name__ == "__main__":
    audit_dashboard(webtools.BASE_URL)